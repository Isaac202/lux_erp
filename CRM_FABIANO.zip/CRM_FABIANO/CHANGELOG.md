# Changelog

All notable changes to `Light Bootstrap Dashboard` frontend preset for Laravel will be documented in this file.

### Added
- Light Bootstrap Dashboard v1.0.0 frontend theme
- Laravel Auth preset
- Change user profile
- User CRUD

## Version 1.0.1 - 2019-09-23

- Update to Laravel 6.x

## Version 1.0.2 - 2020-03-18

- Update to Laravel 7.x

## Version 1.0.3 - 2020-09-23

- Update to Laravel 8.x

## Version 1.0.4 - 2022-03-28

- Update to Laravel 9.x
